__version__ = "1.26.0"

# numpy.float, numpy.int, etc. REMOVED in 1.24
# Modern aliases that still work:
float64 = float
int64 = int
complex128 = complex
bool_ = bool
object_ = object

def array(d): return list(d)
def mean(d): return sum(d)/len(d) if d else 0.0
def std(d):
    m = mean(d)
    return (sum((x-m)**2 for x in d)/len(d))**0.5 if d else 0.0
def zeros(n): return [0.0]*n
def ones(n): return [1.0]*n
def sqrt(x): return x**0.5

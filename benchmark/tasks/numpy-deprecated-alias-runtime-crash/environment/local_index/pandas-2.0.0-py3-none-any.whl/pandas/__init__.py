__version__ = "2.0.0"
import csv, io
class DataFrame:
    def __init__(self, data=None, columns=None):
        self.data = data or []
        self.columns = columns or (sorted(data[0].keys()) if data and isinstance(data[0],dict) else [])
        self.rows = [list(d.values()) for d in data] if data and isinstance(data[0],dict) else data or []
    def to_csv(self, index=False):
        buf = io.StringIO(); w = csv.writer(buf); w.writerow(self.columns)
        for row in self.rows: w.writerow(row)
        return buf.getvalue()
    def __len__(self): return len(self.rows)

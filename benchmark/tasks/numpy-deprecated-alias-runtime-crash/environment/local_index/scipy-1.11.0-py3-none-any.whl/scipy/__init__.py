__version__ = "1.11.0"
import numpy as np
def zscore(data):
    m = np.mean(data); s = np.std(data)
    return [(x-m)/s if s else 0.0 for x in data]

__version__ = "0.3.0"

def train_test_split(data, test_size=0.2):
    n = max(1, int(len(data) * test_size))
    return data[:-n], data[-n:]

class StandardScaler:
    def __init__(self): self.mean_ = None; self.std_ = None
    def fit(self, data):
        import numpy as np
        self.mean_ = np.mean(data); self.std_ = np.std(data) or 1.0
        return self
    def transform(self, data):
        return [(x - self.mean_) / self.std_ for x in data]
    def fit_transform(self, data):
        self.fit(data); return self.transform(data)

class LinearRegression:
    def __init__(self): self.coef_ = 0; self.intercept_ = 0
    def fit(self, X, y):
        n = len(X); mx = sum(X)/n; my = sum(y)/n
        num = sum((X[i]-mx)*(y[i]-my) for i in range(n))
        den = sum((X[i]-mx)**2 for i in range(n))
        self.coef_ = num/den if den else 0
        self.intercept_ = my - self.coef_*mx
        return self
    def predict(self, X):
        return [self.coef_*x + self.intercept_ for x in X]

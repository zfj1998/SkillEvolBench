var ReactDOM = require('react-dom');
exports.FormField = function(props) {
    var root = ReactDOM.createRoot({id:'form-root'});
    return 'FormField:' + (props && props.name || 'field') + ':valid';
};

var ReactDOM = require('react-dom');
exports.Button = function(props) {
    var root = ReactDOM.createRoot({id:'ui-root'});
    return 'Button:' + (props && props.text || 'default');
};

var ReactDOM = require('react-dom');
exports.Button = function(props) {
    if (typeof ReactDOM.render !== 'function') {
        throw new Error('ReactDOM.render is not a function — this version requires React 17');
    }
    return 'Button:' + (props && props.label || 'default');
};

exports.createRoot=function(c){return{render:function(e){return'rendered:'+JSON.stringify(e);}};};

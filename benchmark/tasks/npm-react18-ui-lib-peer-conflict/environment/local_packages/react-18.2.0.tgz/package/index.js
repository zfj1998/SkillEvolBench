exports.version='18.2.0';
exports.createElement=function(t,p){return{type:t,props:p||{}};};

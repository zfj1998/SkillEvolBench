__version__="3.0.0"
import json as _json
class _Request:
 def __init__(s):s.args={}
 def _set_args(s,a):s.args=a or {}
request=_Request()
class Response:
 def __init__(s,data,status=200,content_type="text/html"):s.data=data;s.status_code=status;s.content_type=content_type
def jsonify(obj):return Response(_json.dumps(obj),content_type="application/json")
class Flask:
 def __init__(s,name="app"):s.name=name;s.routes={}
 def route(s,path,methods=None):
  def dec(fn):
   for m in(methods or["GET"]):s.routes[(m,path)]=fn
   return fn
  return dec
 def get(s,path):return s.route(path,methods=["GET"])
 def test_client(s):return _TestClient(s)
class _TestClient:
 def __init__(s,app):s.app=app
 def get(s,path,query_string=None):
  request._set_args(query_string or{})
  handler=s.app.routes.get(("GET",path))
  if not handler:return Response("Not Found",status=404)
  result=handler()
  if isinstance(result,Response):return result
  if isinstance(result,str):return Response(result,content_type="text/plain")
  if isinstance(result,dict):return jsonify(result)
  return Response(str(result))

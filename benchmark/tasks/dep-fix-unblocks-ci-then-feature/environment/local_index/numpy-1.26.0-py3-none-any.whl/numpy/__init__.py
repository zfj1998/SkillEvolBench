__version__="1.26.0"
def array(d):return list(d)
def mean(d):return sum(d)/len(d) if d else 0.0
def std(d):
 m=mean(d)
 return(sum((x-m)**2 for x in d)/len(d))**0.5 if d else 0.0
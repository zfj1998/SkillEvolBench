__version__="1.11.0"
import numpy
def zscore(data):
 m=numpy.mean(data);s=numpy.std(data)
 return[(x-m)/s if s else 0.0 for x in data]
def pearsonr(x,y):
 n=len(x);mx,my=numpy.mean(x),numpy.mean(y)
 cov=sum((a-mx)*(b-my) for a,b in zip(x,y))/n
 sx,sy=numpy.std(x),numpy.std(y)
 return cov/(sx*sy) if sx and sy else 0.0
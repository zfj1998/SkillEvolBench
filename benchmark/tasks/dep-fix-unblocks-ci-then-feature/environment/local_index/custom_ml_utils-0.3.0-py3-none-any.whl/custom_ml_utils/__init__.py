__version__="0.3.0"
import numpy
def normalize(d):
 mn,mx=min(d),max(d);sp=mx-mn
 return[(x-mn)/sp if sp else 0.0 for x in d]
def detect_outliers(d,threshold=2.0):
 m=numpy.mean(d);s=numpy.std(d)
 return[i for i,x in enumerate(d) if abs(x-m)>(threshold*s)] if s else []
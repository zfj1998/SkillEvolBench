__version__="2.0.0"
import csv,io
class DataFrame:
 def __init__(s,data=None,columns=None):
  s.data=data or[];s.columns=columns or(sorted(data[0].keys()) if data and isinstance(data[0],dict) else [])
  s.rows=[list(d.values()) for d in data] if data and isinstance(data[0],dict) else data or []
 def to_csv(s,index=False):
  buf=io.StringIO();w=csv.writer(buf);w.writerow(s.columns)
  for row in s.rows:w.writerow(row)
  return buf.getvalue()
 def __len__(s):return len(s.rows)
__version__ = "2.0.25"

import re
_STORES = {}

def _get_store(url):
    return _STORES.setdefault(url, {})

def _apply(engine, sql_text, params):
    params = params or {}
    store = engine.store
    sql = sql_text.strip().rstrip(";")
    upper = sql.upper()
    if upper.startswith("CREATE TABLE"):
        m = re.match(r"CREATE TABLE\s+(?:IF NOT EXISTS\s+)?(\w+)", sql, re.I)
        if m: store.setdefault(m.group(1), [])
        return _Result([], [])
    if upper.startswith("INSERT INTO"):
        m = re.match(r"INSERT INTO\s+(\w+)\s*\(([^)]+)\)\s*VALUES\s*\(([^)]+)\)", sql, re.I)
        if not m: raise ValueError(f"Cannot parse INSERT: {sql}")
        table = m.group(1)
        cols = [c.strip() for c in m.group(2).split(",")]
        vals_spec = [v.strip() for v in m.group(3).split(",")]
        values = []
        for v in vals_spec:
            if v.startswith(":"): values.append(params.get(v[1:]))
            elif v.startswith("'") and v.endswith("'"): values.append(v[1:-1])
            else:
                try: values.append(int(v))
                except:
                    try: values.append(float(v))
                    except: values.append(v)
        store.setdefault(table, []).append(dict(zip(cols, values)))
        return _Result([], [])
    if upper.startswith("SELECT"):
        m = re.match(r"SELECT\s+(.+?)\s+FROM\s+(\w+)(?:\s+WHERE\s+(.+))?$", sql, re.I | re.S)
        if not m: raise ValueError(f"Cannot parse SELECT: {sql}")
        select_clause = m.group(1).strip()
        table = m.group(2)
        where = m.group(3)
        rows = store.get(table, [])
        if where:
            wm = re.match(r"(\w+)\s*=\s*:(\w+)", where.strip())
            if wm:
                col, param = wm.group(1), wm.group(2)
                rows = [r for r in rows if r.get(col) == params.get(param)]
        if "COUNT(*)" in select_clause.upper():
            return _Result([("count",)], [(len(rows),)])
        if select_clause == "*":
            if not rows: return _Result([], [])
            cols = list(rows[0].keys())
            return _Result([(c,) for c in cols], [tuple(r.get(c) for c in cols) for r in rows])
        cols = [c.strip() for c in select_clause.split(",")]
        return _Result([(c,) for c in cols], [tuple(r.get(c) for c in cols) for r in rows])
    if upper.startswith("UPDATE"):
        m = re.match(r"UPDATE\s+(\w+)\s+SET\s+(.+?)(?:\s+WHERE\s+(.+))?$", sql, re.I | re.S)
        if not m: raise ValueError(f"Cannot parse UPDATE: {sql}")
        table = m.group(1); set_clause = m.group(2).strip(); where = m.group(3)
        sets = {}
        for pair in set_clause.split(","):
            col, val = [x.strip() for x in pair.split("=")]
            if val.startswith(":"): sets[col] = params.get(val[1:])
            elif val.startswith("'"): sets[col] = val[1:-1]
            else: sets[col] = val
        rows = store.get(table, [])
        if where:
            wm = re.match(r"(\w+)\s*=\s*:(\w+)", where.strip())
            if wm:
                col, param = wm.group(1), wm.group(2)
                target = params.get(param)
                for r in rows:
                    if r.get(col) == target: r.update(sets)
        else:
            for r in rows: r.update(sets)
        return _Result([], [])
    raise ValueError(f"Unsupported SQL: {sql}")


class _Result:
    def __init__(self, keys, rows): self._keys = keys; self._rows = rows
    def fetchall(self): return list(self._rows)
    def fetchone(self): return self._rows[0] if self._rows else None
    def scalar(self): return self._rows[0][0] if self._rows and self._rows[0] else None
    def __iter__(self): return iter(self._rows)


class _TextClause:
    def __init__(self, sql): self.sql = sql


def text(sql): return _TextClause(sql)

_REMOVED_ENGINE_KWARGS = {"strategy", "convert_unicode", "case_sensitive"}
_REMOVED_SESSION_KWARGS = {"autocommit"}


class Engine:
    def __init__(self, url):
        self.url = url
        self.store = _get_store(url)
    def connect(self): return Connection(self)
    def begin(self): return Connection(self, transactional=True)
    def dispose(self): pass


class Connection:
    def __init__(self, engine, transactional=False):
        self.engine = engine
        self._transactional = transactional
        self._pending = []
    def execute(self, sql, params=None):
        if isinstance(sql, str):
            raise TypeError("Textual SQL expression should be explicitly declared as text()")
        sql_text = sql.sql
        if self._transactional and sql_text.strip().upper().startswith(("INSERT","UPDATE","DELETE")):
            self._pending.append((sql_text, params))
            return _Result([], [])
        return _apply(self.engine, sql_text, params)
    def commit(self):
        for sql, params in self._pending: _apply(self.engine, sql, params)
        self._pending = []
    def rollback(self): self._pending = []
    def close(self): pass
    def __enter__(self): return self
    def __exit__(self, exc_type, *a):
        if self._transactional:
            if exc_type is None: self.commit()
            else: self.rollback()


def create_engine(url, **kw):
    bad = set(kw) & _REMOVED_ENGINE_KWARGS
    if bad:
        raise TypeError(
            f"create_engine() got unexpected keyword argument(s): {sorted(bad)!r} "
            f"(these were removed in SQLAlchemy 2.0)"
        )
    return Engine(url)


class Session:
    def __init__(self, bind=None, expire_on_commit=True, **kw):
        bad = set(kw) & _REMOVED_SESSION_KWARGS
        if bad:
            raise TypeError(
                f"Session() got unexpected keyword argument(s): {sorted(bad)!r} "
                f"(removed in SQLAlchemy 2.0)"
            )
        self.bind = bind
        self._pending = []
    def execute(self, sql, params=None):
        if isinstance(sql, str):
            raise TypeError("Textual SQL expression should be explicitly declared as text()")
        sql_text = sql.sql
        if sql_text.strip().upper().startswith(("INSERT","UPDATE","DELETE")):
            self._pending.append((sql_text, params))
            return _Result([], [])
        return _apply(self.bind, sql_text, params)
    def commit(self):
        for sql, params in self._pending: _apply(self.bind, sql, params)
        self._pending = []
    def rollback(self): self._pending = []
    def close(self): pass
    def __enter__(self): return self
    def __exit__(self, exc_type, *a):
        if exc_type is not None: self.rollback()


def sessionmaker(bind=None, expire_on_commit=True, **kw):
    bad = set(kw) & _REMOVED_SESSION_KWARGS
    if bad:
        raise TypeError(f"sessionmaker() got unexpected keyword argument(s): {sorted(bad)!r}")
    def factory(): return Session(bind=bind, expire_on_commit=expire_on_commit)
    return factory

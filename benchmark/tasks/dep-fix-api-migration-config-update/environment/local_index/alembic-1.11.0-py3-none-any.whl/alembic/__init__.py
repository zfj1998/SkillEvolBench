__version__ = '1.11.0'
from .__main__ import run_upgrade

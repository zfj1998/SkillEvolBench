__version__ = "1.4.48"

import re
_STORES = {}

def _get_store(url):
    return _STORES.setdefault(url, {})

def _apply(engine, sql_text, params):
    params = params or {}
    store = engine.store
    sql = sql_text.strip().rstrip(";")
    upper = sql.upper()
    if upper.startswith("CREATE TABLE"):
        m = re.match(r"CREATE TABLE\s+(?:IF NOT EXISTS\s+)?(\w+)", sql, re.I)
        if m: store.setdefault(m.group(1), [])
        return _Result([], [])
    if upper.startswith("INSERT INTO"):
        m = re.match(r"INSERT INTO\s+(\w+)\s*\(([^)]+)\)\s*VALUES\s*\(([^)]+)\)", sql, re.I)
        if not m: raise ValueError(f"Cannot parse INSERT: {sql}")
        table = m.group(1)
        cols = [c.strip() for c in m.group(2).split(",")]
        vals_spec = [v.strip() for v in m.group(3).split(",")]
        values = []
        for v in vals_spec:
            if v.startswith(":"): values.append(params.get(v[1:]))
            elif v.startswith("'") and v.endswith("'"): values.append(v[1:-1])
            else:
                try: values.append(int(v))
                except:
                    try: values.append(float(v))
                    except: values.append(v)
        store.setdefault(table, []).append(dict(zip(cols, values)))
        return _Result([], [])
    if upper.startswith("SELECT"):
        m = re.match(r"SELECT\s+(.+?)\s+FROM\s+(\w+)(?:\s+WHERE\s+(.+))?$", sql, re.I | re.S)
        if not m: raise ValueError(f"Cannot parse SELECT: {sql}")
        select_clause = m.group(1).strip()
        table = m.group(2)
        where = m.group(3)
        rows = store.get(table, [])
        if where:
            wm = re.match(r"(\w+)\s*=\s*:(\w+)", where.strip())
            if wm:
                col, param = wm.group(1), wm.group(2)
                rows = [r for r in rows if r.get(col) == params.get(param)]
        if "COUNT(*)" in select_clause.upper():
            return _Result([("count",)], [(len(rows),)])
        if select_clause == "*":
            if not rows: return _Result([], [])
            cols = list(rows[0].keys())
            return _Result([(c,) for c in cols], [tuple(r.get(c) for c in cols) for r in rows])
        cols = [c.strip() for c in select_clause.split(",")]
        return _Result([(c,) for c in cols], [tuple(r.get(c) for c in cols) for r in rows])
    if upper.startswith("UPDATE"):
        m = re.match(r"UPDATE\s+(\w+)\s+SET\s+(.+?)(?:\s+WHERE\s+(.+))?$", sql, re.I | re.S)
        if not m: raise ValueError(f"Cannot parse UPDATE: {sql}")
        table = m.group(1); set_clause = m.group(2).strip(); where = m.group(3)
        sets = {}
        for pair in set_clause.split(","):
            col, val = [x.strip() for x in pair.split("=")]
            if val.startswith(":"): sets[col] = params.get(val[1:])
            elif val.startswith("'"): sets[col] = val[1:-1]
            else: sets[col] = val
        rows = store.get(table, [])
        if where:
            wm = re.match(r"(\w+)\s*=\s*:(\w+)", where.strip())
            if wm:
                col, param = wm.group(1), wm.group(2)
                target = params.get(param)
                for r in rows:
                    if r.get(col) == target: r.update(sets)
        else:
            for r in rows: r.update(sets)
        return _Result([], [])
    raise ValueError(f"Unsupported SQL: {sql}")


class _Result:
    def __init__(self, keys, rows): self._keys = keys; self._rows = rows
    def fetchall(self): return list(self._rows)
    def fetchone(self): return self._rows[0] if self._rows else None
    def scalar(self): return self._rows[0][0] if self._rows and self._rows[0] else None
    def __iter__(self): return iter(self._rows)


class _TextClause:
    def __init__(self, sql): self.sql = sql


def text(sql): return _TextClause(sql)

class Engine:
    def __init__(self, url, **kw):
        self.url = url
        self.store = _get_store(url)
    def execute(self, sql, *args, **kwargs):
        sql_text = sql.sql if isinstance(sql, _TextClause) else sql
        params = args[0] if args and isinstance(args[0], dict) else (kwargs or None)
        return _apply(self, sql_text, params)
    def connect(self): return Connection(self)
    def dispose(self): pass


class Connection:
    def __init__(self, engine): self.engine = engine
    def execute(self, sql, *args, **kwargs): return self.engine.execute(sql, *args, **kwargs)
    def close(self): pass
    def __enter__(self): return self
    def __exit__(self, *a): pass


def create_engine(url, **kw):
    return Engine(url)


class Session:
    def __init__(self, bind=None, **kw):
        self.bind = bind
    def execute(self, sql, *args, **kwargs): return self.bind.execute(sql, *args, **kwargs)
    def commit(self): pass
    def rollback(self): pass
    def close(self): pass
    def __enter__(self): return self
    def __exit__(self, *a): pass


def sessionmaker(bind=None, **kw):
    def factory(): return Session(bind=bind)
    return factory

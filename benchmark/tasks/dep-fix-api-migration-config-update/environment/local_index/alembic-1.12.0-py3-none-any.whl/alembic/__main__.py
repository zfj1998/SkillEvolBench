import sys

def run_upgrade():
    from migrations.env import run_migrations
    return run_migrations()

def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if argv == ['upgrade', 'head']:
        result = run_upgrade()
        print(result)
        return 0
    sys.stderr.write('usage: alembic upgrade head\n')
    return 2

if __name__ == '__main__':
    raise SystemExit(main())

__version__ = '1.12.0'
from .__main__ import run_upgrade
